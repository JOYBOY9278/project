import React, { useState } from 'react';
import { Camera, Settings2, List, UploadCloud, Play, Pause } from 'lucide-react';

function App() {
  const [isRunning, setIsRunning] = useState(false);
  const [detections, setDetections] = useState([
    { label: 'Person', confidence: 0.95 },
    { label: 'Water bottle', confidence: 0.87 },
    { label: 'Smart Phone', confidence: 0.92 }
  ]);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Camera className="h-8 w-8 text-indigo-600" />
            <h1 className="text-2xl font-bold text-gray-900">Object Detection Dashboard</h1>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 rounded-lg hover:bg-gray-100">
              <Settings2 className="h-5 w-5 text-gray-600" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Video Feed */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-lg font-semibold text-gray-900">Live Feed</h2>
                <button 
                  onClick={() => setIsRunning(!isRunning)}
                  className={`px-4 py-2 rounded-md flex items-center space-x-2 ${
                    isRunning ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                  }`}
                >
                  {isRunning ? (
                    <>
                      <Pause className="h-4 w-4" />
                      <span>Stop</span>
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4" />
                      <span>Start</span>
                    </>
                  )}
                </button>
              </div>
              <div className="aspect-video bg-black relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-gray-400">Camera feed will appear here</p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Detection List */}
            <div className="bg-white rounded-lg shadow-md">
              <div className="p-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900 flex items-center">
                  <List className="h-5 w-5 mr-2 text-indigo-600" />
                  Current Detections
                </h2>
              </div>
              <div className="p-4">
                <div className="space-y-3">
                  {detections.map((detection, index) => (
                    <div key={index} className="bg-gray-50 p-3 rounded-lg">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-gray-900">{detection.label}</span>
                        <span className="text-sm text-gray-500">
                          {(detection.confidence * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="mt-2 h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-indigo-600 rounded-full"
                          style={{ width: `${detection.confidence * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Upload Section */}
            <div className="bg-white rounded-lg shadow-md p-4">
              <div className="text-center">
                <UploadCloud className="h-8 w-8 mx-auto text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">Upload Video</h3>
                <p className="mt-1 text-sm text-gray-500">Upload a video file for analysis</p>
                <div className="mt-4">
                  <button className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 w-full">
                    Select File
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;